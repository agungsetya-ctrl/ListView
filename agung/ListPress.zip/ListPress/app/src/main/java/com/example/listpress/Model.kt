package com.example.listpress

class Model (val title:String, val desc:String, val photo:Int){
}